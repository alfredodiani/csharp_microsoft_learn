# Challenge-project-Create-methods-in-CSharp

Starter and Final code for the Challenge project: "Create methods C# console applications" from the Microsoft Learn collection "Getting started with C#"
